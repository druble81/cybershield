#!/bin/bash


cd /home/pi/Desktop

bash loadrd.sh 950 1050