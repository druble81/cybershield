sudo pkill -f adf4351


/home/pi/Desktop/AIModules/adf43519&
/home/pi/Desktop/AIModules/adf4351&
/home/pi/Desktop/AIModules/adf43512&
/home/pi/Desktop/AIModules/adf43513&
/home/pi/Desktop/AIModules/adf43514&
/home/pi/Desktop/AIModules/adf43515&
/home/pi/Desktop/AIModules/adf43516&
/home/pi/Desktop/AIModules/adf43517&
/home/pi/Desktop/AIModules/adf43518&


sudo pkill -f adf4351
clear

/home/pi/Desktop/AIModules/adf43519&
/home/pi/Desktop/AIModules/adf4351&
/home/pi/Desktop/AIModules/adf43512&
/home/pi/Desktop/AIModules/adf43513&
/home/pi/Desktop/AIModules/adf43514&
/home/pi/Desktop/AIModules/adf43515&
/home/pi/Desktop/AIModules/adf43516&
/home/pi/Desktop/AIModules/adf43517&
/home/pi/Desktop/AIModules/adf43518&




