#!/bin/bash


cd /home/pi/Desktop

bash loadrd.sh 300 2000