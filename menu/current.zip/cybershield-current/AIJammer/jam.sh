cd /home/pi/Desktop
./adf4351 50&
./adf43512 50&
./adf43514 50&
./adf43515 50&
./adf43517 50&
./adf43518 50&
./adf43519 50&
