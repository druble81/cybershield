cd /home/pi/Desktop/testmodules
#bash /home/pi/Desktop/alloffrd.sh

BB=300

./adf4351 $BB 25000000 1
./adf43512 $BB.000003 25000000 1
##100000
