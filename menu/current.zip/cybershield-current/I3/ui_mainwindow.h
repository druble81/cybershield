/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.11.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QSlider>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QRadioButton *radioButton;
    QRadioButton *radioButton_2;
    QRadioButton *radioButton_3;
    QRadioButton *radioButton_4;
    QRadioButton *radioButton_5;
    QRadioButton *radioButton_6;
    QRadioButton *radioButton_7;
    QRadioButton *radioButton_8;
    QRadioButton *radioButton_9;
    QRadioButton *radioButton_10;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;
    QPushButton *pushButton_4;
    QPushButton *pushButton_5;
    QPushButton *pushButton_6;
    QLabel *label;
    QLabel *label_2;
    QSlider *horizontalSlider_2;
    QSlider *horizontalSlider_3;
    QRadioButton *radioButton_11;
    QWidget *widget;
    QPushButton *pushButton_7;
    QPushButton *pushButton_8;
    QPushButton *pushButton_9;
    QPushButton *pushButton_10;
    QPushButton *pushButton_11;
    QPushButton *pushButton_12;
    QPushButton *pushButton_13;
    QPushButton *pushButton_14;
    QPushButton *pushButton_15;
    QLabel *label_3;
    QPushButton *pushButton_16;
    QPushButton *pushButton_17;
    QPushButton *pushButton_18;
    QPushButton *pushButton_19;
    QRadioButton *radioButton_12;
    QRadioButton *radioButton_13;
    QRadioButton *radioButton_14;
    QRadioButton *radioButton_15;
    QRadioButton *radioButton_16;
    QRadioButton *radioButton_17;
    QRadioButton *radioButton_18;
    QRadioButton *radioButton_19;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->setWindowModality(Qt::ApplicationModal);
        MainWindow->resize(1036, 474);
        QSizePolicy sizePolicy(QSizePolicy::Maximum, QSizePolicy::Maximum);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(MainWindow->sizePolicy().hasHeightForWidth());
        MainWindow->setSizePolicy(sizePolicy);
        MainWindow->setContextMenuPolicy(Qt::PreventContextMenu);
        MainWindow->setToolButtonStyle(Qt::ToolButtonTextOnly);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        radioButton = new QRadioButton(centralWidget);
        radioButton->setObjectName(QStringLiteral("radioButton"));
        radioButton->setGeometry(QRect(30, -10, 148, 55));
        QFont font;
        font.setPointSize(28);
        font.setBold(true);
        font.setItalic(true);
        font.setWeight(75);
        radioButton->setFont(font);
        radioButton->setChecked(true);
        radioButton_2 = new QRadioButton(centralWidget);
        radioButton_2->setObjectName(QStringLiteral("radioButton_2"));
        radioButton_2->setGeometry(QRect(30, 40, 215, 55));
        radioButton_2->setFont(font);
        radioButton_3 = new QRadioButton(centralWidget);
        radioButton_3->setObjectName(QStringLiteral("radioButton_3"));
        radioButton_3->setGeometry(QRect(40, 280, 121, 55));
        radioButton_3->setFont(font);
        radioButton_4 = new QRadioButton(centralWidget);
        radioButton_4->setObjectName(QStringLiteral("radioButton_4"));
        radioButton_4->setGeometry(QRect(30, 100, 165, 55));
        radioButton_4->setFont(font);
        radioButton_5 = new QRadioButton(centralWidget);
        radioButton_5->setObjectName(QStringLiteral("radioButton_5"));
        radioButton_5->setGeometry(QRect(30, 160, 246, 55));
        radioButton_5->setFont(font);
        radioButton_6 = new QRadioButton(centralWidget);
        radioButton_6->setObjectName(QStringLiteral("radioButton_6"));
        radioButton_6->setGeometry(QRect(40, 220, 162, 55));
        radioButton_6->setFont(font);
        radioButton_6->setChecked(false);
        radioButton_7 = new QRadioButton(centralWidget);
        radioButton_7->setObjectName(QStringLiteral("radioButton_7"));
        radioButton_7->setGeometry(QRect(300, 160, 287, 55));
        radioButton_7->setFont(font);
        radioButton_8 = new QRadioButton(centralWidget);
        radioButton_8->setObjectName(QStringLiteral("radioButton_8"));
        radioButton_8->setGeometry(QRect(300, -10, 178, 55));
        radioButton_8->setFont(font);
        radioButton_9 = new QRadioButton(centralWidget);
        radioButton_9->setObjectName(QStringLiteral("radioButton_9"));
        radioButton_9->setGeometry(QRect(300, 110, 140, 55));
        radioButton_9->setFont(font);
        radioButton_10 = new QRadioButton(centralWidget);
        radioButton_10->setObjectName(QStringLiteral("radioButton_10"));
        radioButton_10->setGeometry(QRect(300, 50, 191, 55));
        radioButton_10->setFont(font);
        pushButton = new QPushButton(centralWidget);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(820, 160, 160, 51));
        QFont font1;
        font1.setPointSize(24);
        font1.setBold(true);
        font1.setItalic(true);
        font1.setWeight(75);
        pushButton->setFont(font1);
        pushButton_2 = new QPushButton(centralWidget);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(820, 210, 160, 51));
        pushButton_2->setFont(font1);
        pushButton_3 = new QPushButton(centralWidget);
        pushButton_3->setObjectName(QStringLiteral("pushButton_3"));
        pushButton_3->setGeometry(QRect(820, 260, 160, 51));
        pushButton_3->setFont(font1);
        pushButton_4 = new QPushButton(centralWidget);
        pushButton_4->setObjectName(QStringLiteral("pushButton_4"));
        pushButton_4->setGeometry(QRect(820, 310, 160, 51));
        pushButton_4->setFont(font1);
        pushButton_5 = new QPushButton(centralWidget);
        pushButton_5->setObjectName(QStringLiteral("pushButton_5"));
        pushButton_5->setGeometry(QRect(820, 360, 160, 51));
        pushButton_5->setFont(font1);
        pushButton_6 = new QPushButton(centralWidget);
        pushButton_6->setObjectName(QStringLiteral("pushButton_6"));
        pushButton_6->setGeometry(QRect(420, 350, 211, 41));
        label = new QLabel(centralWidget);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(380, 220, 101, 47));
        QFont font2;
        font2.setPointSize(26);
        font2.setBold(true);
        font2.setItalic(true);
        font2.setWeight(75);
        label->setFont(font2);
        label_2 = new QLabel(centralWidget);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(590, 220, 77, 47));
        label_2->setFont(font2);
        horizontalSlider_2 = new QSlider(centralWidget);
        horizontalSlider_2->setObjectName(QStringLiteral("horizontalSlider_2"));
        horizontalSlider_2->setGeometry(QRect(270, 320, 521, 26));
        horizontalSlider_2->setMinimum(35);
        horizontalSlider_2->setMaximum(4200);
        horizontalSlider_2->setPageStep(1);
        horizontalSlider_2->setValue(2043);
        horizontalSlider_2->setOrientation(Qt::Horizontal);
        horizontalSlider_3 = new QSlider(centralWidget);
        horizontalSlider_3->setObjectName(QStringLiteral("horizontalSlider_3"));
        horizontalSlider_3->setGeometry(QRect(270, 270, 521, 26));
        horizontalSlider_3->setMinimum(35);
        horizontalSlider_3->setMaximum(4200);
        horizontalSlider_3->setPageStep(1);
        horizontalSlider_3->setValue(883);
        horizontalSlider_3->setOrientation(Qt::Horizontal);
        radioButton_11 = new QRadioButton(centralWidget);
        radioButton_11->setObjectName(QStringLiteral("radioButton_11"));
        radioButton_11->setGeometry(QRect(40, 360, 201, 55));
        radioButton_11->setFont(font);
        widget = new QWidget(centralWidget);
        widget->setObjectName(QStringLiteral("widget"));
        widget->setEnabled(true);
        widget->setGeometry(QRect(0, 430, 1011, 451));
        widget->setAutoFillBackground(true);
        pushButton_7 = new QPushButton(widget);
        pushButton_7->setObjectName(QStringLiteral("pushButton_7"));
        pushButton_7->setGeometry(QRect(290, 90, 99, 81));
        pushButton_7->setFont(font);
        pushButton_8 = new QPushButton(widget);
        pushButton_8->setObjectName(QStringLiteral("pushButton_8"));
        pushButton_8->setGeometry(QRect(400, 90, 99, 81));
        pushButton_8->setFont(font);
        pushButton_9 = new QPushButton(widget);
        pushButton_9->setObjectName(QStringLiteral("pushButton_9"));
        pushButton_9->setGeometry(QRect(510, 90, 99, 81));
        pushButton_9->setFont(font);
        pushButton_10 = new QPushButton(widget);
        pushButton_10->setObjectName(QStringLiteral("pushButton_10"));
        pushButton_10->setGeometry(QRect(290, 180, 99, 81));
        pushButton_10->setFont(font);
        pushButton_11 = new QPushButton(widget);
        pushButton_11->setObjectName(QStringLiteral("pushButton_11"));
        pushButton_11->setGeometry(QRect(400, 180, 99, 81));
        pushButton_11->setFont(font);
        pushButton_12 = new QPushButton(widget);
        pushButton_12->setObjectName(QStringLiteral("pushButton_12"));
        pushButton_12->setGeometry(QRect(510, 180, 99, 81));
        pushButton_12->setFont(font);
        pushButton_13 = new QPushButton(widget);
        pushButton_13->setObjectName(QStringLiteral("pushButton_13"));
        pushButton_13->setGeometry(QRect(290, 270, 99, 81));
        pushButton_13->setFont(font);
        pushButton_14 = new QPushButton(widget);
        pushButton_14->setObjectName(QStringLiteral("pushButton_14"));
        pushButton_14->setGeometry(QRect(400, 270, 99, 81));
        pushButton_14->setFont(font);
        pushButton_15 = new QPushButton(widget);
        pushButton_15->setObjectName(QStringLiteral("pushButton_15"));
        pushButton_15->setGeometry(QRect(510, 270, 99, 81));
        pushButton_15->setFont(font);
        label_3 = new QLabel(widget);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(370, 20, 161, 51));
        QFont font3;
        font3.setPointSize(36);
        font3.setBold(true);
        font3.setItalic(true);
        font3.setWeight(75);
        label_3->setFont(font3);
        pushButton_16 = new QPushButton(widget);
        pushButton_16->setObjectName(QStringLiteral("pushButton_16"));
        pushButton_16->setGeometry(QRect(760, 110, 131, 61));
        pushButton_17 = new QPushButton(widget);
        pushButton_17->setObjectName(QStringLiteral("pushButton_17"));
        pushButton_17->setGeometry(QRect(760, 260, 131, 61));
        pushButton_18 = new QPushButton(centralWidget);
        pushButton_18->setObjectName(QStringLiteral("pushButton_18"));
        pushButton_18->setGeometry(QRect(820, -10, 161, 90));
        pushButton_18->setFont(font3);
        pushButton_19 = new QPushButton(centralWidget);
        pushButton_19->setObjectName(QStringLiteral("pushButton_19"));
        pushButton_19->setGeometry(QRect(820, 90, 160, 51));
        pushButton_19->setFont(font1);
        radioButton_12 = new QRadioButton(centralWidget);
        radioButton_12->setObjectName(QStringLiteral("radioButton_12"));
        radioButton_12->setGeometry(QRect(570, 40, 100, 30));
        radioButton_12->setFont(font);
        radioButton_13 = new QRadioButton(centralWidget);
        radioButton_13->setObjectName(QStringLiteral("radioButton_13"));
        radioButton_13->setGeometry(QRect(570, -10, 100, 50));
        radioButton_13->setFont(font);
        radioButton_14 = new QRadioButton(centralWidget);
        radioButton_14->setObjectName(QStringLiteral("radioButton_14"));
        radioButton_14->setGeometry(QRect(590, 160, 151, 55));
        radioButton_14->setFont(font);
        radioButton_15 = new QRadioButton(centralWidget);
        radioButton_15->setObjectName(QStringLiteral("radioButton_15"));
        radioButton_15->setGeometry(QRect(570, 120, 131, 40));
        radioButton_15->setFont(font);
        radioButton_16 = new QRadioButton(centralWidget);
        radioButton_16->setObjectName(QStringLiteral("radioButton_16"));
        radioButton_16->setGeometry(QRect(570, 80, 131, 30));
        radioButton_16->setFont(font);
        radioButton_17 = new QRadioButton(centralWidget);
        radioButton_17->setObjectName(QStringLiteral("radioButton_17"));
        radioButton_17->setGeometry(QRect(440, 110, 71, 55));
        radioButton_17->setFont(font);
        radioButton_18 = new QRadioButton(centralWidget);
        radioButton_18->setObjectName(QStringLiteral("radioButton_18"));
        radioButton_18->setGeometry(QRect(490, 50, 71, 55));
        radioButton_18->setFont(font);
        radioButton_19 = new QRadioButton(centralWidget);
        radioButton_19->setObjectName(QStringLiteral("radioButton_19"));
        radioButton_19->setGeometry(QRect(670, 40, 120, 30));
        radioButton_19->setFont(font);
        MainWindow->setCentralWidget(centralWidget);
        radioButton_14->raise();
        radioButton_9->raise();
        pushButton_4->raise();
        pushButton_2->raise();
        pushButton->raise();
        pushButton_3->raise();
        pushButton_18->raise();
        radioButton_13->raise();
        radioButton_7->raise();
        radioButton_17->raise();
        pushButton_5->raise();
        radioButton_19->raise();
        radioButton_10->raise();
        radioButton_15->raise();
        radioButton_16->raise();
        radioButton_18->raise();
        radioButton_8->raise();
        pushButton_19->raise();
        radioButton_12->raise();
        radioButton->raise();
        radioButton_2->raise();
        radioButton_3->raise();
        radioButton_4->raise();
        radioButton_5->raise();
        radioButton_6->raise();
        pushButton_6->raise();
        label->raise();
        label_2->raise();
        horizontalSlider_2->raise();
        horizontalSlider_3->raise();
        radioButton_11->raise();
        widget->raise();
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 1036, 28));
        MainWindow->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        MainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        MainWindow->setStatusBar(statusBar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", nullptr));
        radioButton->setText(QApplication::translate("MainWindow", "Normal", nullptr));
        radioButton_2->setText(QApplication::translate("MainWindow", "Burst Mode", nullptr));
        radioButton_3->setText(QApplication::translate("MainWindow", "STOP", nullptr));
        radioButton_4->setText(QApplication::translate("MainWindow", "Full 10K", nullptr));
        radioButton_5->setText(QApplication::translate("MainWindow", "Full Coverage", nullptr));
        radioButton_6->setText(QApplication::translate("MainWindow", "Random", nullptr));
        radioButton_7->setText(QApplication::translate("MainWindow", "Quad Hetrodyne", nullptr));
        radioButton_8->setText(QApplication::translate("MainWindow", "Low EMF", nullptr));
        radioButton_9->setText(QApplication::translate("MainWindow", "DLPFC", nullptr));
        radioButton_10->setText(QApplication::translate("MainWindow", "Anti PTSD", nullptr));
        pushButton->setText(QApplication::translate("MainWindow", "300-400", nullptr));
        pushButton_2->setText(QApplication::translate("MainWindow", "495-505", nullptr));
        pushButton_3->setText(QApplication::translate("MainWindow", "2150-2350", nullptr));
        pushButton_4->setText(QApplication::translate("MainWindow", "4100-4200", nullptr));
        pushButton_5->setText(QApplication::translate("MainWindow", "35-110", nullptr));
        pushButton_6->setText(QApplication::translate("MainWindow", "Set Custom Range", nullptr));
        label->setText(QApplication::translate("MainWindow", "883", nullptr));
        label_2->setText(QApplication::translate("MainWindow", "2043", nullptr));
        radioButton_11->setText(QApplication::translate("MainWindow", "Shutdown", nullptr));
        pushButton_7->setText(QApplication::translate("MainWindow", "1", nullptr));
        pushButton_8->setText(QApplication::translate("MainWindow", "2", nullptr));
        pushButton_9->setText(QApplication::translate("MainWindow", "3", nullptr));
        pushButton_10->setText(QApplication::translate("MainWindow", "4", nullptr));
        pushButton_11->setText(QApplication::translate("MainWindow", "5", nullptr));
        pushButton_12->setText(QApplication::translate("MainWindow", "6", nullptr));
        pushButton_13->setText(QApplication::translate("MainWindow", "7", nullptr));
        pushButton_14->setText(QApplication::translate("MainWindow", "8", nullptr));
        pushButton_15->setText(QApplication::translate("MainWindow", "9", nullptr));
        label_3->setText(QString());
        pushButton_16->setText(QApplication::translate("MainWindow", "OK", nullptr));
        pushButton_17->setText(QApplication::translate("MainWindow", "CLEAR", nullptr));
        pushButton_18->setText(QApplication::translate("MainWindow", "LOCK", nullptr));
        pushButton_19->setText(QApplication::translate("MainWindow", "V2K", nullptr));
        radioButton_12->setText(QApplication::translate("MainWindow", "V2k", nullptr));
        radioButton_13->setText(QApplication::translate("MainWindow", "PFC", nullptr));
        radioButton_14->setText(QApplication::translate("MainWindow", "Mode 2", nullptr));
        radioButton_15->setText(QApplication::translate("MainWindow", "Sleep", nullptr));
        radioButton_16->setText(QApplication::translate("MainWindow", "Wake", nullptr));
        radioButton_17->setText(QApplication::translate("MainWindow", "2", nullptr));
        radioButton_18->setText(QApplication::translate("MainWindow", "2", nullptr));
        radioButton_19->setText(QApplication::translate("MainWindow", "V2k2", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
