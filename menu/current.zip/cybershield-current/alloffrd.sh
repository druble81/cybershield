sudo pkill -f start
sudo pkill -f sa
sudo pkill -f 10k
sudo pkill -f adf4351
sudo pkill -f RAND
sudo pkill -f sleep
sudo pkill -f 1020
sudo pkill -f dtra
sudo pkill -f t1
sudo pkill -f t2
sudo pkill -f dtmenu

/home/pi/Desktop/testmodules/adf4351& 
/home/pi/Desktop/testmodules/adf43512&
/home/pi/Desktop/testmodules/adf43513&
/home/pi/Desktop/testmodules/adf43514&
/home/pi/Desktop/testmodules/adf43515&
/home/pi/Desktop/testmodules/adf43516&
/home/pi/Desktop/testmodules/adf43517&
/home/pi/Desktop/testmodules/adf43518&
/home/pi/Desktop/testmodules/adf43519
