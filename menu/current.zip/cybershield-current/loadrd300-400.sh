#!/bin/bash


cd /home/pi/Desktop
/home/pi/Desktop/dfmodules/dfmenu&
bash loadrd.sh 300 400

