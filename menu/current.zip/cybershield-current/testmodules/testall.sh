C=2

./adf4351 500.5 25000000 $C
./adf4351 500.5 25000000 $C
echo 1 on
sleep 1
./adf4351
echo 1 off
sleep 1
./adf43512 500.5 25000000 $C
./adf43512 500.5 25000000 $C
echo 2 on
sleep 1
./adf43512
echo 2 off
sleep 1
./adf43513 500.5 25000000 $C
./adf43513 500.5 25000000 $C
echo 3 on
sleep 1
./adf43513
echo 3 off
sleep 1
./adf43514 500.5 25000000 $C
./adf43514 500.5 25000000 $C
echo 4 on
sleep 1
./adf43514
echo 4 off
sleep 1
./adf43515 500.5 25000000 $C
./adf43515 500.5 25000000 $C
echo 5 on
sleep 1
./adf43515
echo 5 off
sleep 1
./adf43516 500.5 25000000 $C
./adf43516 500.5 25000000 $C
echo 6 on
sleep 1
./adf43516
echo 6 off
sleep 1
./adf43517 500.5 25000000 $C
./adf43517 500.5 25000000 $C
echo 7 on
sleep 1
./adf43517
echo 7 off
sleep 1
./adf43518 500.5 25000000 $C
./adf43518 500.5 25000000 $C
echo 8 on
sleep 1
./adf43518
echo 8 off
sleep 1
./adf43519 500.5 25000000 $C
./adf43519 500.5 25000000 $C
echo 9 on
sleep 1
./adf43519
echo 9 off
sleep 1
