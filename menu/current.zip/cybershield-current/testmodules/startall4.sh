cd /home/pi/Desktop/
bash 1020.sh
