cd /home/pi/Desktop
bash opennormal.sh
bash open10k.sh
bash opentm.sh
bash openpfc.sh
bash openai.sh
bash open1020.sh