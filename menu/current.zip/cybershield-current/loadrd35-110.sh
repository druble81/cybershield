#!/bin/bash

#bash loadrd.sh 35 110
cd  /home/pi/Desktop/menu
python3 /home/pi/Desktop/menu/menu.py
