sudo chmod +x /home/pi/Desktop/I3/interface3
cd /home/pi/Desktop
sudo chmod +x adf4351
sudo chmod +x adf43512
sudo chmod +x adf43513
sudo chmod +x adf43514
sudo chmod +x adf43515
sudo chmod +x adf43516
sudo chmod +x adf43517
sudo chmod +x adf43518
sudo chmod +x adf43519
sudo chmod +x jam.sh
sudo chmod +x update_gui1
sudo chmod +x update_gui
sudo chmod +x testmenu.py
sudo chmod +x sa4.sh
sudo chmod +x sa5.sh
sudo chmod +x sa6.sh
sudo chmod +x sa7.sh
sudo chmod +x loadrd
sudo chmod +x lock.py
sudo chmod +x powertest
sudo chmod +x timing.py
sudo chmod +x timing10.py


sudo chmod +x ramdisk.sh
sudo chmod +x loadrdDEW.sh
sudo chmod +x loadrd.sh
sudo chmod +x startall.sh
sudo chmod +x alloffrd.sh
sudo chmod +x startPTSD.sh
sudo chmod +x startDLPFC.sh
sudo chmod +x startall2.sh
sudo chmod +x startall3.sh
sudo chmod +x startall6.sh
sudo chmod +x startPTSD2.sh
sudo chmod +x startDLPFC2.sh
sudo chmod +x 1020.sh

cd /home/pi/Desktop/menu
sudo chmod +x menu.py


cd /home/pi/Desktop/JAM
sudo chmod +x adf4351
sudo chmod +x adf43512
sudo chmod +x adf43513
sudo chmod +x adf43514
sudo chmod +x adf43515
sudo chmod +x adf43516
sudo chmod +x adf43517
sudo chmod +x adf43518
sudo chmod +x adf43519
sudo chmod +x jammer_gui.py

cd /home/pi/Desktop/1020
sudo chmod +x adf4351
sudo chmod +x adf43512
sudo chmod +x adf43513
sudo chmod +x adf43514
sudo chmod +x adf43515
sudo chmod +x adf43516
sudo chmod +x adf43517
sudo chmod +x adf43518
sudo chmod +x adf43519

cd /home/pi/Desktop/n2
sudo chmod +x startall.sh
sudo chmod +x adf4351
sudo chmod +x adf43512
sudo chmod +x adf43513
sudo chmod +x adf43514
sudo chmod +x adf43515
sudo chmod +x adf43516
sudo chmod +x adf43517
sudo chmod +x adf43518
sudo chmod +x adf43519

cd /home/pi/Desktop/n3
sudo chmod +x startall.sh
sudo chmod +x adf4351
sudo chmod +x adf43512
sudo chmod +x adf43513
sudo chmod +x adf43514
sudo chmod +x adf43515
sudo chmod +x adf43516
sudo chmod +x adf43517
sudo chmod +x adf43518
sudo chmod +x adf43519

cd /home/pi/Desktop/n4
sudo chmod +x startall.sh
sudo chmod +x adf4351
sudo chmod +x adf43512
sudo chmod +x adf43513
sudo chmod +x adf43514
sudo chmod +x adf43515
sudo chmod +x adf43516
sudo chmod +x adf43517
sudo chmod +x adf43518
sudo chmod +x adf43519


cd /home/pi/Desktop/10k2
sudo chmod +x 10k.sh
sudo chmod +x adf4351
sudo chmod +x adf43512
sudo chmod +x adf43513
sudo chmod +x adf43514
sudo chmod +x adf43515
sudo chmod +x adf43516
sudo chmod +x adf43517
sudo chmod +x adf43518
sudo chmod +x adf43519

cd /home/pi/Desktop/10k3
sudo chmod +x 10k.sh
sudo chmod +x adf4351
sudo chmod +x adf43512
sudo chmod +x adf43513
sudo chmod +x adf43514
sudo chmod +x adf43515
sudo chmod +x adf43516
sudo chmod +x adf43517
sudo chmod +x adf43518
sudo chmod +x adf43519


cd /home/pi/Desktop/10k4
sudo chmod +x 10k.sh
sudo chmod +x adf4351
sudo chmod +x adf43512
sudo chmod +x adf43513
sudo chmod +x adf43514
sudo chmod +x adf43515
sudo chmod +x adf43516
sudo chmod +x adf43517
sudo chmod +x adf43518
sudo chmod +x adf43519


cd /home/pi/Desktop/10k
sudo chmod +x adf4351
sudo chmod +x adf43512
sudo chmod +x adf43513
sudo chmod +x adf43514
sudo chmod +x adf43515
sudo chmod +x adf43516
sudo chmod +x adf43517
sudo chmod +x adf43518
sudo chmod +x adf43519

cd /home/pi/Desktop/startall2
sudo chmod +x adf4351
sudo chmod +x adf43512
sudo chmod +x adf43513
sudo chmod +x adf43514
sudo chmod +x adf43515
sudo chmod +x adf43516
sudo chmod +x adf43517
sudo chmod +x adf43518
sudo chmod +x adf43519

cd /home/pi/Desktop/AIJammer
sudo chmod +x adf4351
sudo chmod +x adf43512
sudo chmod +x adf43513
sudo chmod +x adf43514
sudo chmod +x adf43515
sudo chmod +x adf43516
sudo chmod +x adf43517
sudo chmod +x adf43518
sudo chmod +x adf43519
sudo chmod +x jam.sh

cd /home/pi/Desktop/startall3
sudo chmod +x adf4351
sudo chmod +x adf43512
sudo chmod +x adf43513
sudo chmod +x adf43514
sudo chmod +x adf43515
sudo chmod +x adf43516
sudo chmod +x adf43517
sudo chmod +x adf43518
sudo chmod +x adf43519

cd /home/pi/Desktop/testmodules
sudo chmod +x adf4351
sudo chmod +x adf43512
sudo chmod +x adf43513
sudo chmod +x adf43514
sudo chmod +x adf43515
sudo chmod +x adf43516
sudo chmod +x adf43517
sudo chmod +x adf43518
sudo chmod +x adf43519

sudo chmod +x adf4351-2
sudo chmod +x adf43512-2
sudo chmod +x adf43513-2
sudo chmod +x adf43514-2
sudo chmod +x adf43515-2
sudo chmod +x adf43516-2
sudo chmod +x adf43517-2
sudo chmod +x adf43518-2
sudo chmod +x adf43519-2

sudo chmod +x startall2.sh
sudo chmod +x startall2-2.sh

sudo chmod +x startall4.sh
sudo chmod +x startall5.sh

cd /home/pi/Desktop/AIModules
sudo chmod +x adf4351
sudo chmod +x adf43512
sudo chmod +x adf43513
sudo chmod +x adf43514
sudo chmod +x adf43515
sudo chmod +x adf43516
sudo chmod +x adf43517
sudo chmod +x adf43518
sudo chmod +x adf43519

cd /home/pi/Desktop
sudo rm update_gui
sudo cp update_gui1 update_gui

cd /home/pi/Desktop/dfmodules
sudo chmod +x dtra.sh
sudo chmod +x dtra2.sh
sudo chmod +x t18.sh
sudo chmod +x t19.sh
sudo chmod +x t20.sh
sudo chmod +x t21.sh
sudo chmod +x t22.sh
sudo chmod +x t23.sh
sudo chmod +x t24.sh
sudo chmod +x t25.sh
sudo chmod +x dfmenu
sudo chmod +x tp

sudo chown -R pi:pi /home/pi/Desktop
sudo chown -R pi:pi /tmp/ramdisk

